package com.cleartax.base;

public interface IAgent {

	public void takeAction();
}
