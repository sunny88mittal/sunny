package com.cleartax.base;

import java.util.List;

public interface IAlgorithm {

	public Token getNextToken(List<Token> tokensList);
}
